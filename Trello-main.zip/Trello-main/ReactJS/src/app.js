function App() {
    return (
      <div className="App">
        <h1>  Hello world with React And HaryPhamdev!
        </h1>
      </div>
    );
  }
  
  export default App;