export const siteConfig ={
name: "NYK",
description: "Collaborate, Manage Projects, and reach new productivity peaks",
};